jQuery( document ).ready(function( $ ) {
	$('.btn-ts').click( function() {
		$('.btn-ts').slideUp();
		$('.treasherlocked').show();
	});
});