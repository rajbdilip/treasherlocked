<?php
// OAuth (OpenID) login types
define('OAUTH_DEFAULT', 0);
define('OAUTH_FACEBOOK', 1);
define('OAUTH_GOOGLE', 2);
define('OAUTH_TWITTER', 3);

?>