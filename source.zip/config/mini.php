<?php

$mini = array(
			'start' 		=> strtotime( '2014-10-29 21:00:00' ),
			'end' 			=> strtotime( '2014-11-06 23:59:59' ),
			'start_hour'	=> strtotime( '21:00:00' ),
			'end_hour'		=> strtotime( '21:00:00' )
		);
?>