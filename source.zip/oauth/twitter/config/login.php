<?php
define( 'REDIRECT_URI', SITE_URL . 'oauth/twitter/login.php' );
?>