<?php
define( 'CONSUMER_KEY', 	'BTNVIX0sSByp7h0ZBmXKaonka' );
define( 'CONSUMER_SECRET', 	'QS4f7fgoq3xOfVy0iUB3mbIcdzZezHMKYJw1I9K8U8F2gQgJUY' );
?>