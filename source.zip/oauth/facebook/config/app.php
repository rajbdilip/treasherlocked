<?php
define('APP_ID', '166305773570726');
define('APP_SECRET', '0b50468879f5033c83dc3b6f1ac7a7da');
?>