<?php
define( 'CLIENT_ID', 		'135406094145-qitei5koqt9j0o3oninl66gfd5fo1man.apps.googleusercontent.com' );
define( 'CLIENT_SECRET', 	'3K_iS_uJ84BAAjtVOd4uzU47' );
?>