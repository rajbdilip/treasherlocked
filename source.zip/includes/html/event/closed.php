<h2>The hunt has ended</h2>
				<a class="btn-effect" href="<?php echo SSTATIC; ?>leaderboard/">SEE LEADERBOARD</a>