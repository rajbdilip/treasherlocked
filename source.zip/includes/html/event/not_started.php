<h2>The hunt begins in</h2>
				<ul class="sixteen columns">
					 <li>
						<span class="days">00</span>
						<p class="timeRefDays">days</p>
					 </li>
					 <li>
					   <span class="hours">00</span>
					   <p class="timeRefHours">hours</p>
					 </li>
					 <li>
					   <span class="minutes">00</span>
					   <p class="timeRefMinutes">minutes</p>
					</li>
					<li>
					  <span class="seconds">00</span>
					  <p class="timeRefSeconds">seconds</p>
					</li>
				</ul>