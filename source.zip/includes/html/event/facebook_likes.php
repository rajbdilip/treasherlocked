<?php 

$ts->upgradeLevel( 1 );
header( 'Location: ' . SITE_URL . 'level/1/' );
exit;

?>